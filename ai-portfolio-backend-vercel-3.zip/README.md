# AI Portfolio Backend for Vercel

This backend is ready to deploy on Vercel and provides a simple API route at `/api/hello`.